<template>
    <div>
        <div
                class="imagePreviewWrapper"
                :style="{ 'background-image': `url(${previewImage})` }"
                @click="selectImage">
        </div>

        <input
                ref="fileInput"
                type="file"
                @input="pickFile">
    </div>
</template>


<script>

    export default {

        data() {
            return {
                previewImage: null
            };
        },

        methods: {
            selectImage () {
                this.$refs.fileInput.click()
            },

            pickFile () {
                let input = this.$refs.fileInput
                let file = input.files
                if (file && file[0]) {
                    let reader = new FileReader
                    reader.onload = e => {
                        this.previewImage = e.target.result
                    }
                    reader.readAsDataURL(file[0])
                    this.$emit('input', file[0])
                }
            }
        }
    }
</script>

<style scoped lang="scss">

    .imagePreviewWrapper {

        width: 100px;
        height: 100px;
        display: block;
        cursor: pointer;
        margin: 0 auto 30px;
        background-size: cover;
        background-position: center center;

    }

</style>